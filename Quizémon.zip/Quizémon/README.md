Quizémon
===========

Développé par Louise ISABEL et Baptiste ROYER
Contacts : <mail1> , <mail2>

# Présentation de Quizémon

Jeu de type PvP (player versus player) où deux joueurs s'affrontent dans un duel de quizémon. Les quizémons sont des créatures pouvant poser des questions, choisies par leur joueur, selon une base de données.
Chaque joueur pose une question par tour, et si l'adversaire répond faux, il perd un point de vie. Le premier arrivé à 0 points de vie à perdu, et le jeu s'arrête alors.
Des captures d'écran illustrant le fonctionnement du logiciel sont proposées dans le répertoire shots.


# Utilisation de <le nom de votre jeu>

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

```
./run.sh
```
Permet le lancement du jeu
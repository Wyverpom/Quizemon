class Commandes extends Program {
    void afficherRegles() {
        println("- Le jeu se déroule en tour par tour." + '\n' +
                            "- Les quizémons possèdent une seule spécialité" + '\n' +
                            "- Lors de votre tour choisissez une question à poser parmis celles proposées." + '\n' +
                            "- Lorsque votre adversaire vous pose une question, écrivez la réponse sans tenir compte des majuscules et espaces." + '\n' +
                            "- Une question mal répondue vous fait perdre un de vos 10 points de vie." + '\n' +
                            "- Le premier des joueurs à 0 points de vie a perdu." + '\n' +
                            "- Autre règles secondaires : https://www.youtube.com/watch?v=dQw4w9WgXcQ");
    }

    void showStats(Quizemon param) {
        println(param.NAME + "     " + param.NICKNAME + "      " + param.TYPE);
    }

    /*public static void afficherEffetSecondaire(Questions question) {
        System.out.println(question.effetSecondaire);
    }*/
}

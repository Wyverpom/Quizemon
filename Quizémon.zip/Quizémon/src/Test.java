class Test extends Program {
    String[] listeQuizemon = new String[]{"Historex", "Géogryph", "Angliskor", "Scienciraptor", "Conjugatron", "Orthogriffon"};

    void algorithm() {
        Main_Game oui = new Main_Game();
        println(oui.contains("C'est Angliskor", "Angliskor"));
    }
}
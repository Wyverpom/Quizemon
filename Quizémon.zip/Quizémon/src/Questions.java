class Questions {
    String[] HISTOIRE = new String[]{
        "Quel est le nom du premier roi de France ?",
        "Quel est le nom du premier empereur de l'empire Romain ?",
        "En quelle année l'Amérique a-t-elle été découverte ?",
        "Par qui l'Amérique a-t-elle été découverte ?",
        "Quelle ville a subi un siège par les romains en -52 avant Jésus-Christ ?",
	    "De quelles couleurs sont les étoiles sur le drapeau américain ?",
	    "Où vit le président des États-Unis pendant son mandat ?",
	    "Stars and Stripes est le surnom du drapeau de quel pays ?",
	    "Qui a été le premier président américain ?",
	    "Qui a été le premier homme à marcher sur la lune ?",
	    "Dans quel pays les Jeux Olympiques ont-ils été inventés ?",
	    "Qui a peint la Joconde ?",
	    "En quelle année Charlemagne est-il sacré empereur ?",
	    "Que s'est-il passé le 14 juillet 1789 ?",
	    "Quelles sont les dates de la Seconde Guerre mondiale ?",
	    "Qui est le premier président de la Ve République française ?",
	    "En quelle année Hugues Capet est-il couronné en France ?",
	    "En quelle année Hitler arrive-t-il au pouvoir en Allemagne ?",
	    "A quand situe-t-on l'apparition de l'homme ? (En nombre d'années, et arrondi, et n'oubliez pas les espaces pour les nombres)",
	    "Quelle est le nom de l'époque avant l'Antiquité ?"	    
    };
    
    String[] GEOGRAPHIE = new String[]{
		"Quelle est la capitale de la France ?",
		"Combien de pays sont collés à la France ?",
		"Combien sommes nous (nombre de milliards) sur Terre ?",
		"Combien y a-t-il de continents ?",
		"Combien y a-t-il de pays ?",
		"Combien y a-t-il d'Etat aux Etats-Unis ?",
		"Quel fleuve traverse Rouen et Paris ?",
		"Combien y a-t-il d'Océan ?",
		"Comment s'appelle la mer entre l'Angleterre et la France ?",
		"Comment s'appelle la mer qui borde le Sud de la France ?",
		"Comment appelle-t-on un pays qui est collé à un autre ? (On dit qu'il est [...])",
		"Sur une carte, quel est le nom du dessin indiquant les 4 directions ?",
		"Quelle est la direction qu'il faut regarder pour voir le soleil se lever ?",
		"Quelle est le nom de la ligne invisible qui divise le monde en deux ?",
		"Quel est le nom du méridien qui passe par Paris ?",
		"Quel est la capitale de la Grèce ?",
		"Quelle est la capitale de l'Angleterre ?",
		"Quel océan se trouve au large des côtes californiennes ?",
	    "Quel état est célèbre pour Hollywood ?",
	    "Quel est le plus grand État d'Amérique ?"
    };
    String[] ANGLAIS = new String[]{
		"Quel jour de l'année est le jour de l'indépendance?",
		"Comment traduit-on UN CHAT en anglais ?",
		"Quelle est la traduction française du mot anglais A KITCHEN ?",
		"Quel est le système politique de l'Angleterre ?",
		"Quelle est la traduction française du mot anglais A DESK ?",
		"Comment traduit-on UNE VACHE en anglais ?",
		"Comment traduit-on UN BRAS en anglais ?",
		"Quelle est la traduction française du mot anglais A BOAT ?",
		"Quelle fête anglophone est celebrée le 24 Novembre ?",
		"Quelle est la traduction française de la phrase THE LITTLE BOY EAT AN APPLE ?",
		"Comment traduit-on LA FILLE DESSINE UN CHIEN ?",
		"You sing Merry Christmas in ...",
		"Quelle proposition est correcte pour dire LA MAITRESSE EST HEUREUSE : 1-The teacher is young 2-The student is happy 3- The student is tall  4-The teacher is happy", 
		"Comment traduit-on LE VENT en anglais ?",
		"Quel mot n'appartient pas au champs lexical de l'école : 1-A pen 2-A bag 3-A gun 4-A desk ",
		"Quel mot n'appartient pas au champs lexical des vêtements : 1-A dress 2-A pullover 3-A knife 4-Shoes ",
		"Quel est la traduction anglaise correcte pour UN MANTEAU : 1- A coal 2- A coat",
		"Comment traduit-on APPRENDRE en anglais ?",
		"Comment se nomme le palais où loge la famille royale anglaise ?",
		"Comment traduit-on en français les mots BURN EVERYTHING ?"
	
	
	
	
	
	
	
    };
    String[] SCIENCES = new String[]{
		"Combien de pattes une araignée a-t-elle ?",
		"Combien y a-t-il de planètes dans notre système solaire ?",
		"Quel est l'animal terrestre le plus rapide ?",
		"Combien de jours dans une année non bissextile ?",
		"Quelle planète de notre système solaire est connue pour avoir un anneau ?",
		"Quel est le plus gros mammifère du monde ?",
		"Combien de couleurs y a-t-il dans un arc-en-ciel ?",
		"Quelle voix chantée est la plus aiguë ? Soprano, ténor ou baryton ?",
		"Un scientifique qui étudie les roches s'appelle quoi ?",
		"Si vous souffrez d'arachnophobie, de quel animal avez-vous peur ?",
		"Deux des planètes de notre système solaire commencent par la lettre M, pouvez-vous les nommer ? (par ordre de proximité du soleil, et séparées d'une virgule et d'un espace)",
		"De quel arbre proviennent les glands ?",
		"Combien d'os les requins ont-ils ?",
		"Quelle est la partie de l'œil humain qui contrôle la quantité de lumière qui traverse la pupille ?",
		"Pouvez-vous nommer l'étoile la plus proche de la Terre ?",
		"Convertir 0 degré Celsius en Fahrenheit",
		"Combien de chambres le cœur a-t-il ?",
		"Lors de quel solstice se produit le jour le plus long de l'année ?",
		"Le CO2 est la formule chimique du...",
		"Combien d'os trouvons-nous dans le corps humain ?"	
    };
    String[] CONJUGAISON = new String[]{
		"Conjugue le verbe MANGER à la première personne du singulier au présent de l'indicatif.",
		"À quel temps est conjugué le verbe JOUER dans la phrase : Je jouerai avec mes amis demain. ?",
		"Conjugue le verbe ETRE à la deuxième personne du pluriel à l'imparfait.",
		"Conjugue le verbe PRENDRE à la première personne du singulier au passé composé.",
		"À quel temps est conjugué le verbe LIRE dans la phrase : Hier, je lisais un livre intéressant. ?",
		"Conjugue le verbe ECOUTER à la deuxième personne du singulier au présent de l'impératif.",
		"Conjugue le verbe JOUER au présent : Je ___________.",
		"Complète : Tu ___________ (manger) ton déjeuner.",
		"Conjugue le verbe ALLER au présent : Nous ___________.",
		"Complète : Vous ___________ (avoir) des amis.",
		"Conjugue le verbe REGARDER à l'imparfait : Elle ___________ la télévision.",
		"Exprime une possibilité avec le verbe POUVOIR : Je ___________ nager.",
		"Raconte une action passée avec le verbe FAIRE : Tu ___________ tes devoirs hier.",
		"Conjugue le verbe SAVOIR au futur : Ils ___________ la réponse.",
		"Raconte une action habituelle avec le verbe VENIR à l'imparfait : Nous ___________ à l'école à pied.",
		"Complète : Tu ___________ (devoir) étudier pour l'examen.",
		"Conjugue le verbe CHANTER au futur : Elle ___________ une chanson.",
		"Exprime un souhait avec le verbe DIRE au subjonctif : Je veux que tu ___________ la vérité.",
		"Exprime une condition avec le verbe ALLER au conditionnel passé : Nous ___________ si tu avais invité.",
		"Raconte une action passée avec le verbe 'prendre' au passé simple : Il ___________ le train."
    };
    String[] ORTHOGRAPHE = new String[]{
		"Parmi ces mots, lequel est mal orthographié ? 1-température 2-grinper 3-timbre",
		"Trouve la bonne orthographe : c'est un récipient qui contient le thé. 1-la théière 2-la téhière 3-l’athéière",
		"Quel est le nom des égouts de Paris : 1-Les catacombes 2- L'hecatacombe 3- Les écatombes",
		"Complète : Tu ___________ (dois/doigt) faire tes devoirs.",
		"a) Appeler / b) Apeler",
		"a) Possède / b) Posède",
		"a) Événement / b) Évènement",
		"a) Consciencieux / b) Conciencieux",
		"a) Quarantaine / b) Quarentaine",
		"a) Décennie / b) Décénie",
		"Voici le livre ____ je t'ai parlé. -> DONT ou DON ?",
		"Il pleut ; ____ , nous allons sortir. -> CEPENDANT ou S'EPANDANT ?",
		"Il faut ____ préparer pour le départ. -> CE ou SE ?",
		"Je ne sais pas ____ tu es. -> OU ou OÙ ?",
		"Il pleut, ____ nous allons sortir.-> ET ou EST ?",
		"Je vais ____ la plage demain. -> A ou À ?",
		"Je vais ____-bas demain. -> LA ou LÀ ?",
		"a) Accueillir / b) Acueillir",
		"a) Illusion / b) Ilusion",
		"a) Nénuphar / b) Nénufar"
    };
}

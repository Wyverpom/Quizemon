public class Quizemon {
    //String SPRITE;
    String NAME;
    String NICKNAME;
    String TYPE;
    Moveset[] MOVESET;
}

class Answers {
    String[] HISTOIRE = new String[]{
        "Clovis",
        "Auguste",
        "1492",
        "Christophe Colomb",
        "Alesia",
        "blanche",
        "maison blanche",
        "Etats-Unis",
        "George Washington",
        "Niel Armstrong",
        "Dans quel pays les Jeux Olympiques ont-ils été inventés ?",
        "Leonard de Vinci",
        "800 ",
        "prise de la Bastille",
        "1939-1945",
        "Charles de Gaulle",
        "987",
        "1933",
        "300 000",
        "préhistoire"	    
    };
    
    String[] GEOGRAPHIE = new String[]{
        "Paris",
        "8",
        "Combien sommes nous (nombre de milliards) sur Terre ?",
        "7",
        "195",
        "50",
        "Seine",
        "5",
        "manche",
        "méditéranée",
        "limitrophe",
        "rosace des vents",
        "est",
        "equateur",
        "greenwich",
        "athenes",
        "londres",
        "pacifique",
        "californie",
        "alaska"
    };
    String[] ANGLAIS = new String[]{
      "4 juillet",
      "cat",
      "cuisine",
      "monarchie constitutionnelle",
      "bureau",
      "cow",
      "arm",
      "bateau",
      "black friday",
      "le petit garçon a mangé une pomme",
      "the girl draws a dog",
      "december",
      "4", 
      "wind",
      "3",
      "3",
      "2",
      "learn",
      "buckingham palace",
      "brule tout"
	
	
	
	
	
	
	
    };
    String[] SCIENCES = new String[]{
      "8",
      "8",
      "guepard",
      "365",
      "saturne",
      "baleine bleue",
      "7",
      "soprano",
      "geologue",
      "araignee",
      "mercure, mars",
      "chene",
      "0",
      "iris",
      "soleil",
      "32",
      "4",
      "ete",
      "dioxyde de carbone",
      "206"	
    };
    String[] CONJUGAISON = new String[]{
		  "mange",
      "futur",
      "jouiez",
      "ai pris",
      "imparfait",
      "ecoute",
      "joue",
      "manges",
      "allons",
      "avons",
      "regardait",
      "peux",
      "faisais",
      "sauront",
      "venons",
      "dois",
      "chantera",
      "dises",
      "allons",
      "prenait"
    };
    String[] ORTHOGRAPHE = new String[]{
      "2",
      "1",
      "1",
      "dois",
      "a",
      "b",
      "b",
      "a",
      "b",
      "a",
      "dont",
      "cependant",
      "se",
      "où",
      "et",
      "à",
      "là",
      "a",
      "a",
      "a"
    };
}

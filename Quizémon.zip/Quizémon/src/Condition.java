class Condition {
    String winCondition(Joueur j1, Joueur j2, int tours) {
        if (tours >= 10 && j1.HEALTH > j2.HEALTH) {
            return "j1";
        } else if (tours >= 10 && j1.HEALTH < j2.HEALTH) {
            return "j2";
        } else if (j1.HEALTH == 0) {
            return "j2";
        } else if (j2.HEALTH == 0) {
            return "j1";
        } else {
            return "None";
        }
    }

    void endMatch(Joueur j1, Joueur j2, int tours) {
        if (winCondition(j1, j2, tours).equals("j1")) {
            System.out.println("Le gagnant est " + j1.NAME);
        } else if (winCondition(j1, j2, tours).equals("j2")) {
            System.out.println("Le gagnant est " + j2.NAME);
        }
    }
}

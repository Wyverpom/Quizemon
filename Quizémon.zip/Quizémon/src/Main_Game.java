class Main_Game extends Program {
    String[] listeQuizemon = new String[]{"Historex", "Géogryph", "Angliskor", "Scienciraptor", "Conjugatron", "Orthogriffon"};
    Joueur[] listeJoueurs = new Joueur[2];
    
    int isNameCorrect(String name) {
        if (equals(minuscule(listeQuizemon[0]), minuscule(name))) {
            return 0;
        } else if (equals(minuscule(listeQuizemon[1]), minuscule(name))) {
            return 1;
        } else if (equals(minuscule(listeQuizemon[2]), minuscule(name))) {
            return 2;
        } else if (equals(minuscule(listeQuizemon[3]), minuscule(name))) {
            return 3;
        } else if (equals(minuscule(listeQuizemon[4]), minuscule(name))) {
            return 4;
        } else if (equals(minuscule(listeQuizemon[5]), minuscule(name))) {
            return 5;
        } else {
            return -1;
        }
    }

    String minuscule(String mot) {
        String retour = "";
        for (int i = 0; i<length(mot); i++) {
            if (charAt(mot, i) >= 'A' && charAt(mot, i) <= 'Z') {
                retour = retour + (char)(charAt(mot, i) + 32);
            } else if (charAt(mot, i) >= 'a' && charAt(mot, i) <= 'z') {
                retour += charAt(mot, i);
            } else if (charAt(mot, i) == 'é' || charAt(mot, i) == 'è' || charAt(mot, i) == 'ê') {
                retour = retour + "e";
            } else if (charAt(mot, i) == 'à') {
                retour = retour + "a";
            } else if (charAt(mot, i) == 'ù') {
                retour = retour + "u";
            } else {
                retour = retour + charAt(mot, i);
            }
        }
        return retour;
    }

    void afficherListeQuizemon() {
        for (int i = 0; i<length(listeQuizemon); i++) {
            println(listeQuizemon[i]);
        }
        println('\n');
    }

    void scriptDuDebut() {
        println("Bienvenue jeunes gens !!!" + '\n' +
                "Vous vous apprêtez à participer à un duel tout particulier !!!" + '\n' +
                "En effet, vous allez vous affronter dans un duel de Quizemon. Quoi ? Qu'est ce que c'est un quizémon ?" + '\n' +
                "Très bien. Laissez moi vous expliquer." + '\n' +
                "Voyez-vous, les Quizémons sont de petites créatures qui ressemblent à des éléments de notre vie au quotidien." + '\n' +
                "Cependant, ils ont la particularité d'être des créatures qui sont doués d'une grande intelligence !!!" + '\n' +
                "En fait, c'est même grâce à ça qu'il peuvent se défendre :  les quizémons ont un sujet, qui sera leur spécialité." + '\n' +
                "Ils attaquent en posant une question, et si l'adversaire répond faux, alors ce dernier perdra de la vie." + '\n' +
                "Rien de bien dangereux, ne vous en faites pas, ils s'en remettront après une séance au sources chaudes." + '\n' +
                "Mais alors comment se déroulent les duels ?" + '\n' +
                "Eh bien rien de plus simple !!! Voici les règles :" + '\n' +
                "- Chacun votre tour, vous allez ordonner à votre quizémon de poser une question à votre adversaire." + '\n' +
                "  S'il répond mal, alors il perd un point, sachant que vous azez tous deux 10 points de vie. Le premier à 0 points à perdu." + '\n' +
                "- Pour répondre, vous devrez attendre que l'on vous dises les mots : 'Quelle est votre réponse ?'." + '\n' +
                "- Les réponses doivent être bien écrites, mais ne vous en faite pas, nous sommes assez laxistes sur les accents et majuscules." + '\n' +
                "- Si jamais vous avez oublié les règles, n'hésitez pas à écrire '!règle'. Les règles vous seront rappelées sous forme condensées" + '\n' +
                "(Si ce même dialogue était réécrit, je pense que vous ne vous serviriez jamais de cette commande" + '\n' +
                /*"- Si jamais vous voulez connaître les effets spéciaux de vos questions, écrivez '![leNomDeLaQuestion]' et n'oubliez pas les crochets !" + '\n' +*/
                '\n' +
                "Maintenant que tout est clair, passons aux choses sérieuse !");
    }

    Joueur creationJoueur(String nom, Joueur player) {
        player.NAME = nom;
        player.HEALTH = 10;
        player.QUIZEMON = chooseAStarter();
        return player;
    }

    Quizemon chooseAStarter() {
        Quizemon creature = new Quizemon();
        println("J'ai ici 6 Quizemon, et c'est à toi de décider celui que tu prendras !");
        println("Nous avons tout d'abord le Quizémon Histoire : Historex. Puis nous avons le Quizémon Géographie : Géogryph. Ensuite le Quizémon Anglais : Angliskor." + '\n' + 
                " En 4e nous avons le Quizémon Sciences : Scienciraptor. Le 5e est le Quizémon Conjugaison : Conjugatron. Et pour finir, le 6e est le Quizémon Orthographe : Orthogriffon.");
        //println("Nous avons tout d'abord [Quizémon 1]. Il est de type [Subject]. [Potentiellement rajouter une petite description]");
        //println("En deuxième, je te présente [Quizémon 2]. Il est de type [Subject]. [Idem]");
        //Faire d'autres println() pour couvrir tous les Quizémon possibles. Possibilité de faire plusieurs Quizémon par matière, à voir
        //lors de l'écriture finale de la méthode.
        println("Alors, lequel vas tu choisir ? Donne moi son nom : ");
        boolean nomCorrect = false;
        String temp;
        do {
            temp = readString();
            nomCorrect = isNameCorrect(temp) >= 0;
            if (!nomCorrect) {
                println("Hmm... Le nom ne semble pas correct. Peux-tu répéter ?");
                println("[Souhaitez-vous la liste des Quizémons ?] (y/n)");
                if (equals(minuscule(readString()), "y")) {
                    afficherListeQuizemon();
                }
            }
        } while (!nomCorrect);
        creature.NAME = minuscule(temp);
        println("Bien ! Que dirais tu de choisir un surnom ?");
        println("[Voulez vous choisir un surnom pour votre " + temp + " ?] (y/n) ");
        if (equals(minuscule(readString()), "y")) {
            print("Veuillez entrer le surnom pour votre " + temp + " : ");
            creature.NICKNAME = readString();
        } else {
            creature.NICKNAME = temp;
        }
        setType(creature);
        return creature;
    }

    void setMoveset(Quizemon param, String matiere) {
        Questions liste1 = new Questions();
        Answers liste2 = new Answers();
        if (equals(matiere, "histoire")) {
            String[] q = liste1.HISTOIRE;
            String[] a = liste2.HISTOIRE;
            param.MOVESET = new Moveset[20];
            for (int indicio = 0; indicio < 20; indicio++) {
                param.MOVESET[indicio] = new Moveset();
                param.MOVESET[indicio].QUESTION = q[indicio];
                param.MOVESET[indicio].ANSWERS = a[indicio];
            }
        } else if (equals(matiere, "geographie")) {
            String[] q = liste1.GEOGRAPHIE;
            String[] a = liste2.GEOGRAPHIE;
            param.MOVESET = new Moveset[20];
            for (int indicio = 0; indicio < 20; indicio++) {
                param.MOVESET[indicio] = new Moveset();
                param.MOVESET[indicio].QUESTION = q[indicio];
                param.MOVESET[indicio].ANSWERS = a[indicio];
            }
        } else if (equals(matiere, "anglais")) {
            String[] q = liste1.ANGLAIS;
            String[] a = liste2.ANGLAIS;
            param.MOVESET = new Moveset[20];
            for (int indicio = 0; indicio < 20; indicio++) {
                param.MOVESET[indicio] = new Moveset();
                param.MOVESET[indicio].QUESTION = q[indicio];
                param.MOVESET[indicio].ANSWERS = a[indicio];
            }
        } else if (equals(matiere, "sciences")) {
            String[] q = liste1.SCIENCES;
            String[] a = liste2.SCIENCES;
            param.MOVESET = new Moveset[20];
            for (int indicio = 0; indicio < 20; indicio++) {
                param.MOVESET[indicio] = new Moveset();
                param.MOVESET[indicio].QUESTION = q[indicio];
                param.MOVESET[indicio].ANSWERS = a[indicio];
            }
        } else if (equals(matiere, "conjugaison")) {
            String[] q = liste1.CONJUGAISON;
            String[] a = liste2.CONJUGAISON;
            param.MOVESET = new Moveset[20];
            for (int indicio = 0; indicio < 20; indicio++) {
                param.MOVESET[indicio] = new Moveset();
                param.MOVESET[indicio].QUESTION = q[indicio];
                param.MOVESET[indicio].ANSWERS = a[indicio];
            }
        } else if (equals(matiere, "orthographe")) {
            String[] q = liste1.ORTHOGRAPHE;
            String[] a = liste2.ORTHOGRAPHE;
            param.MOVESET = new Moveset[20];
            for (int indicio = 0; indicio < 20; indicio++) {
                param.MOVESET[indicio] = new Moveset();
                param.MOVESET[indicio].QUESTION = q[indicio];
                param.MOVESET[indicio].ANSWERS = a[indicio];
            }
        }
    }

    void setType(Quizemon param) {
        Questions liQuestions = new Questions();
        if (equals(param.NAME, "historex")) {
            param.TYPE = "histoire";
            setMoveset(param, "histoire");
        } else if (equals(param.NAME, "geogryph")) {
            param.TYPE = "geographie";
            setMoveset(param, "geographie");
        } else if (equals(param.NAME, "angliskor")) {
            param.TYPE = "anglais";
            setMoveset(param, "anglais");
        } else if (equals(param.NAME, "scienciraptor")) {
            param.TYPE = "sciences";
            setMoveset(param, "sciences");
        } else if (equals(param.NAME, "conjugatron")) {
            param.TYPE = "conjugaison";
            setMoveset(param, "conjugaison");
        } else if (equals(param.NAME, "orthogriffon")) {
            param.TYPE = "orthographe";
            setMoveset(param, "orthographe");
        }
    }

    int[] randomIndices() {
        int[] indices = new int[4];
        int[] disponibles = new int[20];
        int indicesGeneres = 0;
        while (indicesGeneres < 4) {
            int indiceAleatoire = (int)(random() * 20);
            if (disponibles[indiceAleatoire] == 0) {
                indices[indicesGeneres] = indiceAleatoire;
                disponibles[indiceAleatoire] = 1;
                indicesGeneres++;
            }
        }
        
        return indices;
    }

    String[] genQuestions(Quizemon param, int[] indices) {
        String[] retour = new String[]{param.MOVESET[indices[0]].QUESTION, param.MOVESET[indices[1]].QUESTION, param.MOVESET[indices[2]].QUESTION, param.MOVESET[indices[3]].QUESTION};
        return retour;
    }

    String[] genReponses(Quizemon param, int[] indices) {
        String[] retour = new String[]{param.MOVESET[indices[0]].ANSWERS, param.MOVESET[indices[1]].ANSWERS, param.MOVESET[indices[2]].ANSWERS, param.MOVESET[indices[3]].ANSWERS};
        return retour;
    }

    boolean contains(String c2, String c1) {
        int longueurC1 = length(c1);
        int longueurC2 = length(c2);
        for (int indice = 0; indice <= longueurC2 - longueurC1; indice++) {
            boolean correspond = true;
            for (int index = 0; index < longueurC1; index++) {
                if (charAt(c2, indice + index) != charAt(c1, index)) {
                    correspond = false;
                }
            }
            if (correspond) {
                return true;
            }
        }
        return false;
    }

    String checkIsAnswerAndNotCommand() {
        Commandes methode = new Commandes();
        String retour = readString();
        if (!isCommande(retour)) {
            return retour;
        } else {
            methode.afficherRegles();
            return checkIsAnswerAndNotCommand();
        }
    }

    boolean isCommande(String chaine) {
        return contains(purify(chaine), "/rules");
    }

    String purify(String chaine) {
        String retour = "";
        for (int index = 0; index < length(chaine); index++) {
            if (!(charAt(chaine, index) == ' ')) {
                retour = retour + charAt(chaine, index);
            }
        }
        return retour;
    }

    boolean correctAnswer(String chaine, String answer) {
        return contains(minuscule(answer), minuscule(chaine));
    }

    void questionFound(Quizemon param, String question) {
        for (int elt = 0; elt < length(param.MOVESET); elt++) {
            if (equals(question, param.MOVESET[elt].QUESTION)) {
                param.MOVESET[elt].TROUVEE = true;
            }
        }
    }


    boolean turn(Joueur attaquant, Joueur defenseur) {
        println("C'est au tour de " + attaquant.NAME + " de jouer.");
        println("Que dois faire " + attaquant.QUIZEMON.NICKNAME + " ? ");
        int[] indices = randomIndices();
        String[] movePossible = genQuestions(attaquant.QUIZEMON, indices);
        String[] reponses = genReponses(attaquant.QUIZEMON, indices);
        println("[" + movePossible[0] + "] (1) " + '\n' + "[" + movePossible[1] + "] (2) " + '\n' + "[" + movePossible[2] + "] (3) " + '\n' + "[" + movePossible[3] + "] (4) ");
        print("[Veuillez entrer le numéro de la question que vous voulez poser] : ");
        int choix = readInt() - 1;
        String questionChoisie = movePossible[choix];
        String reponseConsequente = reponses[choix];
        println(questionChoisie);
        println(defenseur.NAME + ", quelle est votre réponse ?");
        String choice = checkIsAnswerAndNotCommand();
        if (!correctAnswer(choice, reponseConsequente)) {
            println("Mauvaise réponse ! " + defenseur.NAME + ", vous perdez un point de vie. Il vous reste [" + (defenseur.HEALTH - 1) + "] points de vie.");
            defenseur.HEALTH--;
            if (defenseur.HEALTH == 0) {
                println(defenseur.NAME + ", vous avez perdu !. La victoire revient donc à : " + attaquant.NAME + " !!!");
                return true;
            }
            println("======= FIN DE TOUR =======");
        } else if (correctAnswer(choice, reponseConsequente)) {
            println("Bonne réponse ! " + defenseur.NAME + ", vous ne perdez pas de points de vie. Vous avez donc toujours [" + defenseur.HEALTH + "] points de vie.");
            questionFound(attaquant.QUIZEMON.MOVESET, questionChoisie);
            println("======= FIN DE TOUR =======");
        }
        return false;
    }

    void algorithm() {
        Joueur joueur1 = new Joueur();
        Joueur joueur2 = new Joueur();
        Commandes commandes = new Commandes();
        scriptDuDebut();
        println("Quel est ton nom, premier joueur ?");
        joueur1 = creationJoueur(readString(), joueur1);
        println("Parfait ! Au tour du deuxième joueur maintenant ! Quel est ton nom ?");
        joueur2 = creationJoueur(readString(), joueur2);
        listeJoueurs[0] = joueur1;
        listeJoueurs[1] = joueur2;
        commandes.showStats(joueur1.QUIZEMON);
        println("");
        commandes.showStats(joueur2.QUIZEMON);
        println(joueur1.HEALTH + "    " + joueur2.HEALTH);
        println("Bien, je vois que tout est prêt alors... https://youtu.be/bsNRJxqQiGE?si=ek6OGf2YX75-3_0q !!!");
        boolean endGame = false;
        int nbTours = 25;
        while (!endGame && nbTours > 0) {
            if (nbTours%2 == 1) {
                endGame = turn(joueur1, joueur2);
            } else {
                endGame = turn(joueur2, joueur1);
            }
            nbTours--;
        }
    }
}
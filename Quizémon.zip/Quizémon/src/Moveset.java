class Moveset {
    String QUESTION;
    String ANSWERS;
    //String EFFET_SECONDAIRE;
    boolean TROUVEE = false;
}

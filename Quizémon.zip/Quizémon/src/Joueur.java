class Joueur {
    int HEALTH;
    String NAME;
    Quizemon QUIZEMON;
}
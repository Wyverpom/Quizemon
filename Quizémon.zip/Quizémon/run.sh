#!/bin/bash
export CLASSPATH=`find ./lib -name "*.jar" | tr '\n' ':'`
export MAINCLASS=Main_Game.java # <- à remplacer par le nom de votre programme
java -cp ${CLASSPATH}:classes $MAINCLASS
# Le programme s'exécute depuis la racine de l'archive
